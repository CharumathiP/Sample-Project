void double_free();

void no_double_free();

void df_by_pointer();

void df_with_wrappers();

void wrapper(char *ptr);

void conditional_dfree();

void free_null();

void double_delete();

void intrnl_reassignment();

void reassignment(char *ptr);

void good_goto();

void bad_goto();
