# double-free-samples
Toy project for sast training
