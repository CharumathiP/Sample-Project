MOVED TO https://github.com/playframework/play-samples
